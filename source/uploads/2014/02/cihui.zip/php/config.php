<?php
    header("Content-type:text/html;charset=utf-8");
    date_default_timezone_set('Asia/Shanghai');
    $link = @mysql_connect("localhost",'root','root',true);
    if(!$link) {
        die("Connect Server Failed: " . mysql_error());
    }
    if(!mysql_select_db('vocabulary',$link)) {
        die("Select Database Failed: " . mysql_error($link));
    }
    mysql_query('set names utf8');
