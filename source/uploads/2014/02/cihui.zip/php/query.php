<?php
    require('config.php');
    
    function url_encode_array($val) {
        if (is_array($val)) {
            foreach ($val as $k=>$v) {
                $val[$k]=url_encode_array($v);
            }
            return $val;
        } else {
            return urlencode($val);
        }
    }
    
    function output($result_array) {
        exit(urldecode(json_encode(url_encode_array($result_array))));
    }
    
    /* $_POST['search_value']='216';
    $_POST['page']='1';
    $_POST['limit']='10'; */
    
    if (!$_POST) {
        output(array('status'=>'error','message'=>'服务器没有接收到数据'));
    }
    
    if (!get_magic_quotes_gpc()) {
        foreach($_POST as $k=>$v) {
            $_POST[$k]=addslashes($v);
        }
    }
    
    if (empty($_POST['search_value'])) {
        output(array('status'=>'error','message'=>'请您仔细阅读说明之后在上方的搜索框中输入您需要查找的项目'));
    }
    
    if (preg_match("/^\d{3}$/",$_POST['search_value'])) {
        if ((int)$_POST['search_value']>250 || (int)$_POST['search_value']<213) {
            output(array('status'=>'error','message'=>'接收到的页码有错误，请再试一次，提示，有效值范围：213-250（含）'));
        } else {
            $select_query=mysql_query('SELECT `id`,`word`, `speech`, `trans` FROM `words` WHERE `word` IN ( SELECT * FROM ( SELECT DISTINCT `word` FROM (select `words`.* from `words`,(select `start_id`,`end_id` from `pages` where `page`='.(int)$_POST['search_value'].') as `t1` where `words`.`id`>=`t1`.`start_id` and `words`.`id`<=`t1`.`end_id` ) as `t2` limit '.(int)$_POST['limit'].' offset '.(((int)$_POST['page']-1)*(int)$_POST['limit']).' )t ) ORDER BY `id`');
            $select_num=mysql_num_rows(mysql_query('SELECT DISTINCT `word` FROM (select `words`.* from `words`,(select `start_id`,`end_id` from `pages` where `page`='.(int)$_POST['search_value'].') as `t1` where `words`.`id`>=`t1`.`start_id` and `words`.`id`<=`t1`.`end_id` ) as `t2`'));
            $op=array();
            while (($row=mysql_fetch_array($select_query))!==false) {
                $op[]=array('word'=>$row['word'],'speech'=>$row['speech'],'trans'=>$row['trans']);
            }
            if ($select_num!=0) {
                output(array('status'=>'success','result_data'=>$op,'max_length'=>ceil($select_num/$_POST['limit'])));
            } else {
                output(array('status'=>'error','message'=>'搜索结果为空'));
            }
        }
    }
    
    $select_query=mysql_query('SELECT `word`, `speech`, `trans` FROM `words` WHERE `word` IN ( SELECT * FROM ( SELECT DISTINCT `word` FROM `words` WHERE `word` LIKE "%'.$_POST['search_value'].'%" OR `trans` LIKE "%'.$_POST['search_value'].'%" limit '.(int)$_POST['limit'].' offset '.(((int)$_POST['page']-1)*(int)$_POST['limit']).' )t ) ORDER BY `word`, `speech`, `trans`');
    $select_num=mysql_num_rows(mysql_query('SELECT DISTINCT `word` FROM `words` WHERE `word` LIKE "%'.$_POST['search_value'].'%" OR `trans` LIKE "%'.$_POST['search_value'].'%"'));
    $op=array();
    while (($row=mysql_fetch_array($select_query))!==false) {
        $op[]=array('word'=>$row['word'],'speech'=>$row['speech'],'trans'=>$row['trans']);
    }
    if ($select_num!=0) {
        output(array('status'=>'success','result_data'=>$op,'max_length'=>ceil($select_num/$_POST['limit'])));
    } else {
        output(array('status'=>'error','message'=>'搜索结果为空'));
    }
?>