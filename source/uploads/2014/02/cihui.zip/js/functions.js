$(function() {
    function GetQueryString(name) {
        var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r!=null) return unescape(r[2]); return null;
    }
    
    function submit_search(search_value) {
        var page=("undefined"!==typeof arguments[1])?parseInt(arguments[1]):1;
        var limit=("undefined"!==typeof arguments[2])?parseInt(arguments[2]):(("undefined"!==typeof $("#limit").val())?parseInt($("#limit").val()):10);
        $("#search_result").html('<div class="alert alert-info">正在加载，请稍候</div>');
        $.ajax({
            type: 'post',
            url: 'php/query.php',
            dataType: 'json',
            timeout: 5000,
            data: {"search_value":search_value, "page":page, "limit":limit},
            success: function(re) {
                if (re['status']=="error") {
                    $("#search_result").html('<div class="alert alert-info">'+re['message']+'</div>');
                } else {
                    var ta='<table class="table table-hover"><tr><th>#</th><th>单词</th><th>词性</th><th>释义</th></tr>';
                    var tmpword;
                    var iii=1;
                    $.each(re['result_data'], function(i,v) {
                        if (tmpword==v['word']) {
                            v['word']='&nbsp;';
                            tiii='&nbsp;';
                        } else {
                            tmpword=v['word'];
                            tiii=iii;
                            iii++;
                        }
                        ta=ta+'<tr><td>'+tiii+'</td><td>'+v['word']+'</td><td>'+v['speech']+'</td><td>'+v['trans']+'</td></tr>';
                    });
                    ta=ta+'</table><p style="text-align: center">';
                    var pgs=5; //显示页数，要求奇数，大于等于 3
                    if (re['max_length']>pgs) {
                        if (page>=((pgs+1)/2+1)) {
                            if (re['max_length']-page<((pgs-1)/2)) {
                                var ti=re['max_length']-(pgs-1);
                            } else {
                                var ti=page-(pgs-1)/2;
                            }
                            var tmpi=ti+(pgs-1);
                        } else {
                            var ti=1;
                            var tmpi=pgs;
                        }
                    } else {
                        var ti=1;
                        var tmpi=re['max_length'];
                    }
                    if (page!==1) {
                        ta=ta+'<a href="####" id="page_'+(page-1)+'">上一页</a>&nbsp;&nbsp;';
                    }
                    if (ti!==1) {
                        ta=ta+'<a href="####" id="page_1">1</a>&nbsp;&nbsp;...&nbsp;&nbsp;';
                    }
                    for (var i=ti;i<=tmpi;i++) {
                        if (i==page) {
                            ta=ta+i+'&nbsp;&nbsp;';
                        } else {
                            ta=ta+'<a href="####" id="page_'+i+'">'+i+'</a>&nbsp;&nbsp;';
                        }
                    }
                    if (tmpi!=re['max_length']) {
                        ta=ta+'...&nbsp;&nbsp;<a href="####" id="page_'+re['max_length']+'">'+re['max_length']+'</a>&nbsp;&nbsp;';
                    }
                    if (page!=re['max_length']) {
                        ta=ta+'<a href="####" id="page_'+(page+1)+'">下一页</a>';
                    }
                    ta=ta+'</p><p style="text-align: right">每页显示<select name="limit" id="limit"><option value="10">10</option><option value="20">20</option><option value="50">50</option><option value="100">100</option></select>个</p>';
                    $("#search_result").html(ta);
                    $("#limit").val(limit);
                }
            },
            error: function(XMLHttpRequest,status) {
                if (status == 'timeout') {
                    $("#search_result").html('<div class="alert alert-warning">请求超时，<a href="####" id="reload");">重新加载</a><span id="page_reload" style="display: none">'+page+'</span><span id="limit_reload" style="display: none">'+limit+'</span></div>');
                    return true;
                } else {
                    $("#search_result").html('<div class="alert alert-danger">无法请求数据</div>');
                    return true;
                }
            }
        });
        return true;
    }
    
    $("#search_submit").click(function() {
        submit_search($("#search_input").val());
    });
    
    $('#search_input').keypress(function(e){
        var keyCode = e.keyCode ? e.keyCode : e.which ? e.which : e.charCode;
        if(keyCode === 13){
            submit_search($("#search_input").val());
            return false;
        }
    });
    
    $("#row2_result").on("click", "a[id^='page_']", function() {
        var id = $(this).attr("id");
        var reg = new RegExp("^page_(.*?)$");
        var r = id.match(reg);
        submit_search($("#search_input").val(),r[1]);
    });
    
    $("#row2_result").on("change", "#limit", function() {
        submit_search($("#search_input").val());
    });
    
    $("#row2_result").on("click", "#reload", function() {
        submit_search($("#search_input").val(),$("#page_reload").html(),$("#limit_reload").html());
    });
    
    getr=GetQueryString("search_input");
    if (getr!==null) {
        $("#search_input").val(getr);
            submit_search(getr);
    }
});