<?php
    /**************************************************************************************/
    /* 百度音乐 lrc 歌词获取工具 api                                                      */
    /* 作者 admin@sxb.pw                                                                  */
    /* 博客 http://www.sxb.pw                                                             */
    /* 返回格式: json 或 jsonp 字符串                                                     */
    /* 包含参数:                                                                          */
    /* status，值为 success 或 error                                                      */
    /* errcode, 值为 0,-1,-2,-3,-4,-5                                                     */
    /*          0 无错误                                                                  */
    /*         -1 为服务器没有接收到完整数据                                              */
    /*         -2 为无法正常获取 xml 文件                                                 */
    /*         -3 为找不到该曲目                                                          */
    /*         -4 为未收录 lrc 歌词                                                       */
    /*         -5 为无法正常获取 lrc 歌词                                                 */
    /* result, 当 status=success 时返回 lrc 歌词数组                                      */
    /* 请求参数: name 歌曲名, singer 歌手名, callback 回调函数（可选）, playerid 可选     */
    /**************************************************************************************/
    
    header("Content-type: text/javascript; charset=utf-8");
    
    function curl_get_contents($url) { //封装 curl
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5); //超时五秒
        $output = curl_exec($ch);
        curl_close($ch);
        if ($output===false) {
            return false;
        }
        return $output;
    }
    
    function url_encode_array($val) { //递归处理数组
        if (is_array($val)) {
            foreach ($val as $k=>$v) {
                $val[$k]=url_encode_array($v);
            }
            return $val;
        } else {
            return urlencode($val);
        }
    }
    
    function output($result_array) { //输出函数
        if ($_GET['playerid'] && $result_array['status']=='success') {
            $playerid=htmlspecialchars($_GET['playerid']);
        }
        echo ($_GET['callback']?htmlspecialchars($_GET['callback']).'(':'').urldecode(json_encode(url_encode_array($result_array))).($_GET['callback']?(($playerid?(',\''.(get_magic_quotes_gpc()?$playerid:addslashes($playerid)).'\''):'').');'):'');
        exit();
    }
    
    //function 部分到此结束
    
    $name=rawurldecode($_GET['name']);
    $singer=rawurldecode($_GET['singer']);
    
    /*
    $name='笨小孩';
    $singer='刘德华';
    */
    
    if ($name=='' || $singer=='') {
        output(array('status'=>'error','errcode'=>-1));
    }
    
    $xml_data=curl_get_contents('http://box.zhangmen.baidu.com/x?op=12&count=1&title='.rawurlencode($name).'$$'.rawurlencode($singer).'$$$$');
    
    if (!$xml_data) {
        output(array('status'=>'error','errcode'=>-2));
    }
    
    if (preg_match("/<count>(\d*?)<\/count>/",$xml_data,$_count)) {
        if ($_count[1]) {
            preg_match_all("/<lrcid>(\d*?)<\/lrcid>/",$xml_data,$_lrcids);
            $lrcid=array_unique($_lrcids[1]);
            $lrc_data=array();
            foreach ($lrcid as $id) {
                if ($lrcid!='0') {
                    $_lrc=str_replace("\n","<br />",iconv('GBK','UTF-8',curl_get_contents('http://box.zhangmen.baidu.com/bdlrc/'.floor($id/100).'/'.$id.'.lrc')));
                    if (!$_lrc) {
                        output(array('status'=>'error','errcode'=>-5));
                    } else {
                        $lrc_data[]=$_lrc;
                    }
                }
            }
            if (empty($lrc_data)) {
                output(array('status'=>'error','errcode'=>-4));
            } else {
                output(array('status'=>'success','errcode'=>0,'result'=>$lrc_data),$_GET['callback']);
            }
        } else {
            output(array('status'=>'error','errcode'=>-3));
        }
    } else {
        output(array('status'=>'error','errcode'=>-2));
    }
?>